import unittest
from unittest.mock import Mock, patch

import requests

from app.providers import metals_xaus
from app.services import market_data


class XausProviderTests(unittest.TestCase):
    def setUp(self):
        self.cache_snapshot = patch.object(metals_xaus, "_cached_snapshot", None)
        self.cache_time = patch.object(metals_xaus, "_last_attempt_at", None)
        self.cache_snapshot.start()
        self.cache_time.start()
        self.addCleanup(self.cache_snapshot.stop)
        self.addCleanup(self.cache_time.stop)

    def _response(self):
        response = Mock()
        response.json.return_value = {
            "xau": {"price": 2600, "currency": "USD"},
            "spot_usd_oz": 2600,
            "silver_usd_oz": 30,
            "fx_rates": {"INR": 80},
            "updated_at": "2026-11-23T00:00:00Z",
        }
        return response

    def test_one_provider_response_supplies_both_metals_and_fx(self):
        with (
            patch("app.providers.metals_xaus.requests.get", return_value=self._response()) as get,
            patch("app.providers.metals_xaus.monotonic", side_effect=[10, 10]),
        ):
            snapshot = metals_xaus.fetch_market_data()
            cached_snapshot = metals_xaus.fetch_market_data()

        self.assertEqual(get.call_count, 1)
        self.assertIs(snapshot, cached_snapshot)
        self.assertEqual(snapshot["fx_rate"], 80)
        self.assertEqual(snapshot["metals"]["XAU"]["provider"], "xaus.com")
        self.assertEqual(snapshot["metals"]["XAG"]["provider"], "xaus.com")

    def test_provider_failure_returns_last_quote_as_stale(self):
        with (
            patch(
                "app.providers.metals_xaus.requests.get",
                side_effect=[self._response(), requests.ConnectionError("offline")],
            ),
            patch("app.providers.metals_xaus.monotonic", side_effect=[0, 6, 6.1]),
        ):
            fresh_snapshot = metals_xaus.fetch_market_data()
            stale_snapshot = metals_xaus.fetch_market_data()
            cached_stale_snapshot = metals_xaus.fetch_market_data()

        self.assertFalse(fresh_snapshot["stale"])
        self.assertTrue(stale_snapshot["stale"])
        self.assertIs(stale_snapshot, cached_stale_snapshot)
        self.assertEqual(stale_snapshot["metals"]["XAU"], fresh_snapshot["metals"]["XAU"])

    @patch(
        "app.services.market_data.get_open_close_delta",
        return_value={"open": 2500},
    )
    @patch("app.services.market_data.metals_xaus.fetch_market_data")
    def test_live_snapshot_uses_both_prices_from_one_provider_snapshot(
        self, fetch_market_data, get_delta
    ):
        fetch_market_data.return_value = {
            "metals": {
                "XAU": {
                    "inr_per_gram": 100,
                    "usd_per_oz": 2600,
                    "provider": "xaus.com",
                    "updated_at": market_data.datetime.now(market_data.timezone.utc),
                },
                "XAG": {
                    "inr_per_gram": 1,
                    "usd_per_oz": 30,
                    "provider": "xaus.com",
                    "updated_at": market_data.datetime.now(market_data.timezone.utc),
                },
            },
            "fx_rate": 80,
            "fx_source": "xaus.com",
            "stale": False,
        }

        snapshot = market_data.get_latest_snapshot()

        fetch_market_data.assert_called_once_with()
        self.assertEqual(snapshot["metals"]["XAU"]["source"], "xaus.com")
        self.assertEqual(snapshot["metals"]["XAG"]["source"], "xaus.com")
        self.assertEqual(snapshot["metals"]["XAU"]["inr_per_10g"], 1000)
        self.assertEqual(snapshot["metals"]["XAG"]["inr_per_10g"], 10)
        self.assertEqual(get_delta.call_count, 2)


if __name__ == "__main__":
    unittest.main()
