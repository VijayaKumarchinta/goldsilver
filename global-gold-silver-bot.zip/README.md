# Gold and Silver Price Bot

## Market data

The dashboard refreshes its backend data every five seconds. Gold, silver, and
USD/INR are read together from the Xaus spot endpoint; the five-second refresh
does not guarantee that the provider publishes a new quote every five seconds.
Values are global spot references, not local retail quotes, so local taxes,
premiums, and jeweller charges can differ.

## Telegram updates on Windows

Telegram updates run as a Windows Scheduled Task and do not require the Flask
backend or Vue frontend to be running. Install the backend requirements and
configure `DATABASE_URL`, `TELEGRAM_BOT_TOKEN`, and at least one enabled
Telegram destination (via `TELEGRAM_CHAT_ID` or the database) in the root `.env`
file.

From PowerShell in this project folder, register the task once:

```powershell
.\install_hourly_task.ps1
```

If you use a virtual environment, pass its Python executable:

```powershell
.\install_hourly_task.ps1 -PythonPath ".\backend\.venv\Scripts\python.exe"
```

The task checks every five minutes and sends when a 30-minute update is due.
On backend startup, the saved send time is checked; an update is sent only if
the 30-minute interval has elapsed. The standalone task keeps updates running
without Flask or Vue. After downtime, the system sends one catch-up update
rather than replaying every missed interval. Historical data contains only
snapshots that were actually captured; a quote from an hour when the computer
was off cannot be reconstructed.

The task runs under your Windows account, so the computer must be on and you
must be signed in. Windows can start a missed run when it becomes available
again. PostgreSQL must be reachable, and the machine needs internet access for
the price provider and Telegram.